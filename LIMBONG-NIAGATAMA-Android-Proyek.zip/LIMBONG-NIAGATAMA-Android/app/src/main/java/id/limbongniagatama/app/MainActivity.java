package id.limbongniagatama.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class AndroidBridge {
        @JavascriptInterface public void shareHtml(String filename, String html) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "shared");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Folder sementara tidak dapat dibuat");
                    File out = new File(dir, "Tabel-Belanja-LIMBONG-NIAGATAMA.html");
                    try (FileOutputStream stream = new FileOutputStream(out)) { stream.write(html.getBytes(StandardCharsets.UTF_8)); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "id.limbongniagatama.app.fileprovider", out);
                    Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/html");
                    send.putExtra(Intent.EXTRA_STREAM, uri); send.putExtra(Intent.EXTRA_SUBJECT, "Tabel Belanja LIMBONG NIAGATAMA");
                    send.putExtra(Intent.EXTRA_TEXT, "File daftar belanja LIMBONG NIAGATAMA. Simpan lampiran sebelum membukanya.");
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Kirim file daftar belanja"));
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Gagal menyiapkan file: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
