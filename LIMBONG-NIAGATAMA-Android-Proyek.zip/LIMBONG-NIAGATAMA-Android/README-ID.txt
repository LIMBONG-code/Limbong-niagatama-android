LIMBONG NIAGATAMA — SUMBER APLIKASI ANDROID

Proyek ini membungkus file HTML WA DIPULIHKAN dalam aplikasi Android WebView. JavaScript dan DOM storage diaktifkan agar fitur HTML dan penyimpanan lokal dapat bekerja. Tombol Kirim File ke WA menggunakan menu berbagi Android untuk mengirim file HTML yang berisi snapshot data saat itu.

CARA MEMBANGUN APK DENGAN GITHUB (bisa dari HP)
1. Ekstrak ZIP ini.
2. Unggah seluruh isi folder proyek ke repository GitHub, bukan hanya ZIP. Struktur folder harus tetap, termasuk .github/workflows/build-apk.yml.
3. Pastikan branch utama bernama main atau master.
4. Buka tab Actions pada repository.
5. Jalankan workflow "Build Android APK" melalui tombol Run workflow, atau lakukan commit agar build otomatis berjalan.
6. Buka hasil workflow yang selesai, unduh artifact "LIMBONG-NIAGATAMA-APK", lalu ekstrak ZIP artifact.
7. Pasang app-debug.apk di Android. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

PENTING
- ZIP ini adalah proyek sumber, bukan APK siap pasang.
- Ini APK debug untuk pengujian, belum rilis final.
- Data disimpan lokal di setiap HP; tidak ada sinkronisasi antar-HP.
- Uji pengiriman WhatsApp di perangkat nyata sebelum dipakai untuk transaksi penting.
- Simpan backup file daftar belanja secara berkala.
